module.exports = {
  preset: '@vue/cli-plugin-unit-jest'
}
